function pintaTabla(partides) {
  let tabla = `
    <h2 class="text-center text-light">Partidas</h2>
    <div class="input-group mb-3">
      <input
        type="text"
        class="form-control"
        placeholder="Buscador"
        aria-label="Buscador"
        aria-describedby="button-addon2"
      />
      <button
        class="btn btn-outline-secondary"
        type="button"
        id="button-addon2"
      >
        <i class="bi bi-x-lg"></i>
      </button>
    </div>
    <table class="table table-dark">
      <thead>
        <tr>
          <td></td>
          <td>Nick <i class="bi bi-arrow-up-square"></i></td>
          <td>Puntuación <i class="bi bi-arrow-up-square"></i></td>
          <td>Fecha <i class="bi bi-arrow-up-square"></i></td>
        </tr>
      </thead>
      <tbody>
  `;

  // Agregar filas para cada elemento en el array de datos
  partides.forEach(element => {
    tabla += `
      <tr>
        <td><img src="${element.avatar}" alt="avatar" width=50/></td>
        <td>${element.nick}</td>
        <td>${element.puntos}</td>
        <td>${element.fecha}</td>
      </tr>
    `
  })

  // Cerrar la tabla
  tabla += `
  </tbody>
  <tfoot>
  </tfoot>
  </table>

  `;

  // Inyectar la tabla en el elemento con id "partidas"
  document.querySelector("#partidas").innerHTML = tabla;
}


function pintaRanking() {
  const rankingHTML = `
 
					<h2 class="text-center text-light">Ranking</h2>
					<table class="table table-dark align-middle">
						<theader>
							<tr class="bg-dark">
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</theader>
						<tbody>
							<tr>
								<td class="fs-2">1</td>
								<td><img src="" alt="avatar" /></td>
								<td>Pepe</td>
								<td>1255</td>
							</tr>
							<tr>
								<td class="fs-2">2</td>
								<td><img src="" alt="avatar" /></td>
								<td>ANDER</td>
								<td>1255</td>
							</tr>
							<tr>
								<td class="fs-2">3</td>
								<td><img src="" alt="avatar" /></td>
								<td>ANDER</td>
								<td>1255</td>
							</tr>
						</tbody>
						<tfoot></tfoot>
					</table>
`
document.querySelector('#ranking').innerHTML = rankingHTML;
}

const partides = [
  {
    avatar: "https://www.svgrepo.com/show/384670/account-avatar-profile-user.svg",
    nick: "kiko rivera",
    puntos: "6",
    fecha: "13-12-2022",
  },
  {
    avatar: "https://www.svgrepo.com/show/384669/account-avatar-profile-user-13.svg",
    nick: "faliyo",
    puntos: "3",
    fecha: "13-01-2023",
  },
  {
    avatar: "https://www.svgrepo.com/show/384681/account-avatar-profile-user-16.svg",
    nick: "Manolo lama",
    puntos: "6",
    fecha: "24-05-2023",
  },
];


const datosEjemploPartida = {
  avatar:'https://www.svgrepo.com/show/384672/account-avatar-profile-user-7.svg',
  nick: 'MANUEL' ,
  puntos: 100 ,
  fecha:'21 MAYO 2023' 
  }
  
function insertaNuevaPartida(datosEjemploPartida){
  console.log("Guardando partida")
  console.log(datosEjemploPartida.avatar)
  console.log(datosEjemploPartida.nick)
  console.log(datosEjemploPartida.puntos)
  console.log(datosEjemploPartida.fecha)
  partides.push(datosEjemploPartida)
  partides.forEach( element => {
    console.log(element.avatar)
    console.log(element.nick)
    console.log(element.puntos)
    console.log(element.fecha)
})
}

function pintaDatosPartida(datosEjemploPartida){
  console.log("Datos de la partida")
  console.log(datosEjemploPartida.avatar)
  console.log(datosEjemploPartida.nick)
  console.log(datosEjemploPartida.puntos)
  console.log(datosEjemploPartida.fecha)
  confirm()
  const confirmacion = `
    Avatar: ${datosEjemploPartida.avatar}
    nick: ${datosEjemploPartida.nick}
    puntos: ${datosEjemploPartida.puntos}
    fecha: ${datosEjemploPartida.fecha} 
    ¿Deseas guardar la partida?
  
`
  const guardarPartida = confirm(confirmacion);
  if (guardarPartida) {
    insertaNuevaPartida(datosEjemploPartida)
    pintaTabla(partides)
  }
}



console.log('HTML generado por pintaTabla:',pintaTabla)
console.log('HTML generado por pintaRanking:',pintaRanking)
pintaRanking()
pintaDatosPartida(datosEjemploPartida)
insertaNuevaPartida(datosEjemploPartida)